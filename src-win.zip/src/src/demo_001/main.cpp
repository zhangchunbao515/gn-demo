#include <stdio.h>

int main(){

	printf(" helloworld dir ,this is a test\n");
	return 1;
}