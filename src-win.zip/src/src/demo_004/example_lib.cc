#include "example_lib.h"

int example_lib_do_add(int a, int b) {
  return a + b;
}

