#ifndef EXAMPLE_LIB_H_
#define EXAMPLE_LIB_H_

int example_lib_do_add(int a, int b);

#endif // EXAMPLE_LIB_H_
